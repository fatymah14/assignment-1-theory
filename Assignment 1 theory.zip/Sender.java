import java.io.PrintWriter;
import java.net.Socket;

public class Sender {
    private Socket socket;
    private PrintWriter writer;

    public Sender(Socket socket) {
        this.socket = socket;
        try {
            this.writer = new PrintWriter(socket.getOutputStream(), true);
        } catch (Exception e) {
            System.out.println("Error Initializing Sender: " + e.getMessage());
        }
    }

    public void sendMessage(String message) {
        if (writer != null) {
            writer.println(message); 
            System.out.println("Message Sent: " + message);
        } else {
            System.out.println("Unable To Send Message. Writer Is Not Initialized.");
        }
    }
}
