import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Connecting to server...");
        MessagingApp app = new MessagingApp("localhost", 8080); 

        int choice;
        do {
            System.out.println("-----------------------------");
            System.out.println("Enter 1 To Send Message");
            System.out.println("Enter 2 To View Message");
            System.out.println("Enter 3 To Add Contacts");
            System.out.println("Enter 4 To Display Contacts");
            System.out.println("Enter 5 To Display Messages");
            System.out.println("Enter 0 To Exit");
            System.out.println("-----------------------------");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 
            System.out.println("-----------------------------");

            switch (choice) {
                case 1:
                    System.out.print("Enter SenderID: ");
                    String senderID = sc.nextLine();
                    System.out.print("Enter ReceiverID: ");
                    String receiverID = sc.nextLine();
                    System.out.print("Enter The Text: ");
                    String text = sc.nextLine();
                    app.sendMessage(senderID, receiverID, text);
                    break;

                case 2:
                    System.out.print("Enter Sender ID: ");
                    String contactName = sc.nextLine();
                    app.viewMessages(contactName);
                    break;

                case 3:
                    System.out.print("Enter the number of contacts to add: ");
                    int contactNum = sc.nextInt();
                    Contact[] contacts = new Contact[contactNum];
                    sc.nextLine();
                    for (int i = 0; i < contactNum; i++) {
                        System.out.print("Enter Contact Name: ");
                        String naam = sc.nextLine();
                        System.out.print("Enter Contact ID: ");
                        String num = sc.nextLine();
                        contacts[i] = new Contact(naam, num);
                    }
                    app.addContacts(contacts);
                    break;

                case 4:
                    app.displayContacts();
                    break;

                case 5:
                    app.displayMessages();
                    break;

                case 0:
                    app.closeConnection();
                    System.out.println("Exiting The Application.");
                    break;

                default:
                    System.out.println("Invalid Choice. Please Try Again.");
            }
        } while (choice != 0);

        sc.close();
    }
}
